#coding: utf-8
require 'spec_helper'

describe "pictures/show" do

	it "have some linkes " do
	end
end